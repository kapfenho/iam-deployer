for f in [a-z]* ; do ( cd vim-puppet ; git pull ) done
